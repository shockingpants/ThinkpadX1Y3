extern const unsigned char *DisplayMergeNubVersionString;
extern const double DisplayMergeNubVersionNumber;
