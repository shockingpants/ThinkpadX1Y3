* FixEDID - Monitor data patcher and injector for Mac OS X

- Engineering:
Andy Vandijck (AnV Software)
Marchrius

- Human Interface Design:
Andy Vandijck (AnV Software)
Marchrius

- Testing:
Andy Vandijck (AnV Software)
Marchrius
Many other people at InsanelyMac

- Documentation:
Andy Vandijck (AnV Software)

- With special thanks to:
Marchrius for the extra updates
