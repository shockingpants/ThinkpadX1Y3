//
//  main.m
//  FixEDID
//
//  Created by Andy Vandijck on 23/06/13.
//  Copyright (c) 2013 Andy Vandijck. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
